public class hello_java {
    public static void main(String[] args) {
        System.out.println("hello Java");
    }
}