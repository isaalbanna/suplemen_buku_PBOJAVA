import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class applet_konv_suhu extends Applet implements ActionListener {
    Button bt_konversi = new Button("KONVERSI");
    TextField tf_c = new TextField("", 30);
    Label lb_c = new Label("Celcius:");
    String text1 = "......";

    public void init() {
        add(lb_c);
        add(tf_c);
        add(bt_konversi);
        bt_konversi.addActionListener(this);
    }

    public void paint(Graphics myGraphics) {
        myGraphics.drawString("Fahrenheit:", 10, 60);
        myGraphics.drawString(text1, 80, 60);
    }

    public void actionPerformed(ActionEvent ae) {
        Integer data_c = Integer.parseInt(tf_c.getText());
        Double data_fahr = ((9.0 / 5.0) * data_c) + 32;
        text1 = String.valueOf(data_fahr);
        repaint();
    }
}
/* <applet code = "applet_konv_suhu" width = 400 height = 200> </applet> */