import java.applet.*;
import java.awt.*;

public class applet_dasar extends Applet {

    public void paint(Graphics kanvas) {
        kanvas.drawRect(50, 50, 40, 40); // square
        kanvas.drawRect(60, 80, 225, 30); // rectangle
        kanvas.drawOval(75, 65, 20, 20); // circle
        kanvas.drawLine(35, 60, 100, 120); // line
        kanvas.drawString("Java Applet dengan JDK8", 110, 70);
        kanvas.drawString("--by Isa Albanna", 130, 100);
    }
}

/* <applet code = "applet_dasar" width = 400 height = 200> </applet> */